<?php
header('Content-Type: application/json');
require_once "commonFunctions.php";
require_once "functions.php";
//db conn open
$conn = new mysqli("localhost","root", "usbw" , "care2deliver");
if ($conn->connect_errno) {
    echo json_encode(array("dbConnectionFail"=>true));
    exit();
}
// getting request data
$method = $_SERVER['REQUEST_METHOD'];
$params = getRequestParams();
