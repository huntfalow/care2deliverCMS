<?php


function respondWithAllHeadCategories($conn){
    $qry = "SELECT * FROM  `tblheadcategory` ";
    $stmt= $conn->prepare($qry);
    echo json_encode(handleSelectQuery($stmt));
}
function respondHeadCategoryById($conn,$id){

    $qry = "SELECT * FROM  `tblheadcategory` WHERE id=? LIMIT 1";
    $stmt= $conn->prepare($qry);
    $stmt->bind_param("i",$id);
    echo json_encode(handleSelectQuery($stmt));
}
function respondWithAllLangText($conn){
    $qry = "SELECT * FROM  `tbllangtext` ";
    $stmt= $conn->prepare($qry);
    echo json_encode(handleSelectQuery($stmt));
}
function respondLangTextById($conn,$langId,$catId){
    $qry = "SELECT * FROM  `tbllangtext` WHERE langId=? AND categoryId=? LIMIT 1";
    $stmt= $conn->prepare($qry);
    $stmt->bind_param("ii",$langId,$catId);
    echo json_encode(handleSelectQuery($stmt));
}
function respondLangTextByCatId($conn,$catId){
    $qry = "SELECT * FROM  `tbllangtext` WHERE categoryId=?";
    $stmt= $conn->prepare($qry);
    $stmt->bind_param("i",$catId);
    echo json_encode(handleSelectQuery($stmt));
}
function respondWithAllLangs($conn){
    $qry = "SELECT * FROM  `tbllangs` ";
    $stmt= $conn->prepare($qry);
    echo json_encode(handleSelectQuery($stmt));
}
function respondLangById($conn,$id){

    $qry = "SELECT * FROM  `tbllangs` WHERE id=? LIMIT 1";
    $stmt= $conn->prepare($qry);
    $stmt->bind_param("i",$id);
    echo json_encode(handleSelectQuery($stmt));
}
function getLangArray($conn){
    $qry = "SELECT * FROM  `tbllangs` ";
    $stmt= $conn->prepare($qry);
    return handleSelectQuery($stmt);
}
function respondWithAllCategories($conn){
    $qry = "SELECT * FROM  `tblcategory` ";
    $stmt= $conn->prepare($qry);
    echo json_encode(handleSelectQuery($stmt));
}
function respondCategoryById($conn,$id){

    $qry = "SELECT * FROM  `tblcategory` WHERE id=? LIMIT 1";
    $stmt= $conn->prepare($qry);
    $stmt->bind_param("i",$id);
    echo json_encode(handleSelectQuery($stmt));
}
function addCategory($conn,$requestData){
    $qry = "INSERT INTO  `care2deliver`.`tblcategory` (`headCategoryId` ,`name` ,`faName`)VALUES (?,  ?,  ?);";
    $stmt= $conn->prepare($qry);
    $stmt->bind_param("iss",$requestData->headCatId,$requestData->name,$requestData->faName);
    $stmt->execute();
    $catId = $stmt->insert_id;
    // for each lang
    $langs = getLangArray($conn);
    foreach ($langs['data'] as $lang){
        addEmptyLangText($conn,$lang['id'],$catId);
    }
    // get cat to return
    respondCategoryById($conn,$catId);


}
function editCategory($conn,$requestData){
  $qry="UPDATE  `care2deliver`.`tblcategory` SET  `headCategoryId` =  ?,`name` =  ?,`faName` =  ? WHERE  `tblcategory`.`id` =?;";
  $stmt= $conn->prepare($qry);
  $stmt->bind_param("issi",$requestData->headCatId,$requestData->name,$requestData->faName,$requestData->id);
  $stmt->execute();
    return  array("data"=>$requestData);
}
function addEmptyLangText($conn,$langId,$catId){
    $defaultText="";
    $qry = "INSERT INTO  `care2deliver`.`tbllangtext` (`langId` ,`categoryId` , `titel` , `text`)VALUES (?,  ?,  ?,  ?);";
    $stmt= $conn->prepare($qry);
    $stmt->bind_param("iiss",$langId,$catId,$defaultText,$defaultText);
    $stmt->execute();
}
function deleteCategory($conn,$id){
    $qry = "DELETE FROM `care2deliver`.`tblcategory` WHERE `tblcategory`.`id` = ? LIMIT 1;";
    $stmt= $conn->prepare($qry);
    $stmt->bind_param("i",$id);
    $stmt->execute();
    deleteLangTextByCatId($conn,$id);
    return json_encode(array("rowsAffected"=>$conn->affected_rows));
}
function deleteLangTextByCatId($conn,$id){
    $qry="DELETE FROM `care2deliver`.`tbllangtext` WHERE `tbllangtext`.`categoryId` = ? ";
    $stmt= $conn->prepare($qry);
    $stmt->bind_param("i",$id);
    $stmt->execute();
}
function editLangText($conn,$requestData){
  $qry="UPDATE  `care2deliver`.`tbllangtext` SET  `titel` =  ?,`text` =  ? WHERE  `tbllangtext`.`langId` = ? AND  `tbllangtext`.`categoryId` =?;";
  $stmt= $conn->prepare($qry);
  $stmt->bind_param("ssii",$requestData->titel,$requestData->text,$requestData->langId,$requestData->categoryId);
  $stmt->execute();
    return  array("data"=>$requestData);
}
